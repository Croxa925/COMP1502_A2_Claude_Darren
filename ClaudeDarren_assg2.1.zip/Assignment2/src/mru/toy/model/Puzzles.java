package mru.toy.model;

public class Puzzles extends Toy {
	
	private String puzzle_type;

	public Puzzles(String iD, String name, String brand, double price, int available_count,int ageMin, String puzzle_type) {
		super(iD, name, brand, price, available_count,ageMin);
		this.puzzle_type = puzzle_type;
	}

	public String getPuzzle_type() {
		return puzzle_type;
	}

	public void setPuzzle_type(String puzzle_type) {
		this.puzzle_type = puzzle_type;
	}
	
	@Override
	public String toString () {
		return "Category [" + "Puzzle" + ", serialnumber=" + getID() + ", name="+ getName() + ", brand=" + getBrand() +", price=" + getPrice() +", available_count=" + getAvailable_count() +", age appropriation ="+getAgeMin()+", puzzle_type=" + getPuzzle_type() +"]";
	}
	
}