package mru.toy.model;

public class Animals extends Toy{
	
	private String material;
	private int size;

	public Animals(String iD, String name, String brand, double price, int available_count,int ageMin, String material,int size) {
		super(iD, name, brand, price, available_count,ageMin);
		this.material = material;
		this.size = size;
		
		// TODO Auto-generated constructor stub
	}
	
	public String getMaterial() {
		return material;
	}
	
	public void setMaterial(String material) {
		this.material = material;
	}
	
	public int getSize() {
		return size;
	}
	
	public void setSize(int size) {
		this.size = size;
	}
	@Override
	public String toString () {
		return "Category [" + "Animal" + ", serialnumber=" + getID() + ", name="+ getName() + ", brand=" + getBrand() +", price=" + getPrice() +", available_count=" + getAvailable_count() +", age appropriation=" +getAgeMin()+", material=" + material +", size=" + size +"]";
	}
	

}
