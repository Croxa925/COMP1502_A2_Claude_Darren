package mru.toy.model;

public class Toy {
	private String ID;
	private String name;
	private String Brand;
	private double price;
	private int available_count;
	private int ageMin;

	public Toy(String ID, String name, String brand, double price, int available_count,int ageMin) {
		this.ID = ID;
		this.name = name;
		Brand = brand;
		this.price = price;
		this.available_count = available_count;
		this.ageMin = ageMin;
	}

	public String getID() {
		return ID;
	}

	public void setID(String ID) {
		this.ID = ID;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getBrand() {
		return Brand;
	}

	public void setBrand(String brand) {
		Brand = brand;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public int getAvailable_count() {
		return available_count;
	}

	public void setAvailable_count(int available_count) {
		this.available_count = available_count;
	}
	public int getAgeMin () {
		return ageMin;
	}
	
	public void setAgeMin(int ageMin) {
		this.ageMin = ageMin;
	}
	
	public String toString () {
		return "Category [" + null + ", serialnumber=" + getID() + ", name="+ getName() + ", brand=" + getBrand() +", price=" +getPrice() +", available_count=" + getAvailable_count() +", age appropriation= " + getAvailable_count() +"]";
	}
	
}

