package mru.toy.model;

public class BoardGame extends Toy {
	
	private String numOfPlayers;
	//private int minPlayers;
	//private int maxPlayers;

	private String designers;
	public BoardGame(String iD, String name, String brand, double price, int available_count,int ageMin, String numOfPlayers,String designers) {
		
		super(iD, name, brand, price, available_count,ageMin);
		this.numOfPlayers = numOfPlayers;
		//this.minPlayers = minPlayers;
		//this.maxPlayers =maxPlayers;
		this.designers = designers;
		
	}
	public String getNumOfPlayers() {
		return this.numOfPlayers;
	}
	public void setNumOfPlayers(String numOfPlayers) {
		this.numOfPlayers=numOfPlayers;
	}
	
	/*
	public int getMinPlayers() {
		return minPlayers;
	}
	public void setMinPlayers(int minPlayers) {
		this.minPlayers = minPlayers;
	}
	public int getMaxPlayers() {
		return maxPlayers;
	}
	public void setMaxPlayers(int maxPlayers) {
		this.maxPlayers =maxPlayers;
	}*/
	
	
	public String getDesigners() {
		return designers;
	}
	public void setDesigners(String designers) {
		this.designers = designers;
	}
	
	@Override
	public String toString () {
		return "Category [" + "BoardGame" + ", serialnumber=" + getID() + ", name="+ getName() + ", brand=" + getBrand() +", price=" + getPrice() +", available_count=" + getAvailable_count() +", age appropriation="+getAgeMin()+", number_of_players=" + getNumOfPlayers() +", designer=" + getDesigners() +"]";
		//return "Category [" + "BoardGame" + ", serialnumber=" + getID() + ", name="+ getName() + ", brand=" + getBrand() +", price=" + getPrice() +", available_count=" + getAvailable_count() +", age appropriation="+getAgeMin()+", number_of_players=" + getMinPlayers() +"-"+ getMaxPlayers() +", designer=" + getDesigners() +"]";

	}

}
