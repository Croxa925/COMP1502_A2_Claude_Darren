package mru.toy.model;

public class Figure extends  Toy {
	
	private String classification;
	
	public Figure (String iD, String name, String brand, double price, int available_count,int ageMin, String classification) {
		super(iD, name,brand,price,available_count,ageMin);
		this.classification = classification;
	}
	
	public String getClassification() {
		return classification;
	}
	public void setClassification(String classification) {
		this.classification=classification;
	}
	@Override
	public String toString () {
		return "Category [" + "Figure" + ", serialnumber=" + getID() + ", name="+ getName() + ", brand=" + getBrand() +", price=" + getPrice() +", available_count=" + getAvailable_count() +", age appropriation=" +getAgeMin()+", Classification=" +getClassification() +"]";
	}
}
