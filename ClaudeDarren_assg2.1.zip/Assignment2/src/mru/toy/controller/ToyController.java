package mru.toy.controller;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Scanner;

import mru.toy.model.Toy;
import mru.toy.view.ToyMenu;

public class ToyController {
	private final String FILE_PATH = "toys.txt";
	ArrayList <Toy> toys;
	ToyMenu menu;
	
	public ToyController() throws IOException {
		toys = new ArrayList <Toy>();
		menu = new ToyMenu();
		loadData();
		launchApp();
		
	}
	
	
	private void launchApp() throws IOException {
		boolean flag = true;
		String choice;

		while (flag) {
			choice = menu.mainMenu();

			switch (choice) {
			case "1":
				search(menu.submainMenu());
				break;
			case "2":
				//System.out.println(menu.addBasicInfo());
				
				//addInfo()
				//addToy(menu.addToyInfo());
				addToy();
				break;
			case "3":
				removeToy();
				
				break;
			case "4":
				save();
				System.out.println("Thank you for your time!");
				flag = false;
				break;
			default:
				System.out.println("Invalid input, please try again");
				break; 
			}
		}
	}
	


private void save() throws IOException {
		// TODO Auto-generated method stub
	FileWriter dataBase = new FileWriter(FILE_PATH);
	PrintWriter pw = new PrintWriter (dataBase);
	
	System.out.println("Saving...");
	
			
	}


private void search(String choice) throws IOException {
	switch(choice) {
	case "1":
		searchID();
		break;
	case"2":
		searchName();
		break;
	case"3":
		searchType();
		break;
	case "4":
		launchApp();
		
	case "5":
		test();
	
	}
}
private void test() {
	// TODO Auto-generated method stub
	for(Toy t: toys) {
		System.out.println(t.toString());
	}
}
//*****Search Menu methods******************************************************************************************************************
private void searchType() {
	// TODO Auto-generated method stub
	
}


private void searchName() {
	// TODO Auto-generated method stub
	
}


private void searchID() {
	// TODO Auto-generated method stub
	Scanner kb = new Scanner(System.in);
	int id = kb.nextInt();
	
	for(Toy t:toys) {
		if((t.getID().equals(id))== true) {
			System.out.println(t);
		}else {
			System.out.println("Toy Not Found");
		}
	}
}


//***Main Menu methods********************************************************************************************************************
private void removeToy() {
		// TODO Auto-generated method stub
		
	}


private String addToy()  {
	// TODO Auto-generated method stub
	String sn;
	String genericData;
	sn = menu.addSNPrompt();
	genericData = menu.addBasicData();
	String typeData = null;
	String addAllData;
	int first = Character.getNumericValue(sn.charAt(0));
	if (first < 2) {
		//figure 0-1
		typeData = menu.addFigureData(); 
	}else if(first >= 2 && first < 4) {
		//animal 2-3
		typeData = menu.addAnimalData();

	}else if(first >= 4 && first < 7) {
		//puzzle 4-5-6
typeData = menu.addPuzzleData();
	}else if(first >= 7 && first < 10) {
		//board game 7-8-9
typeData = menu.addBoardGameData();
	}else {
		System.out.println("Error");
	}

	return addAllData = sn+genericData+typeData;
	
	
}
/*
private void addType(String serialNumber) {
	// TODO Auto-generated method stub
	int first = Character.getNumericValue(serialNumber.charAt(0));
	

	if (first < 2) {
		//figure 0-1
		

	}else if(first >= 2 && first < 4) {
		//animal 2-3

	}else if(first >= 4 && first < 7) {
		//puzzle 4-5-6

	}else if(first >= 7 && first < 10) {
		//board game 7-8-9

	}

}
*/



//***********************************************************************************************************************


public void loadData() throws FileNotFoundException {
		
		File db = new File (FILE_PATH);
		String currentInfo;
		String[] splittedLine;
		
		if(db.exists()) {
			Scanner fileReader = new Scanner (db);
			
			while (fileReader.hasNextLine()) {
				currentInfo = fileReader.nextLine();
				splittedLine = currentInfo.split(";");
				Toy s = new Toy(splittedLine[0],splittedLine[1],splittedLine[2], Double.parseDouble(splittedLine[3]),Integer.parseInt(splittedLine[4]),Integer.parseInt(splittedLine[5]));
				toys.add(s);
			}
			fileReader.close();
		}
	}
}
