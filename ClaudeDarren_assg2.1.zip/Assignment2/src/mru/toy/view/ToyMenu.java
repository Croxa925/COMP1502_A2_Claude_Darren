package mru.toy.view;

import java.util.Scanner;

public class ToyMenu {
	
	Scanner keyboard;
	
	public ToyMenu() {
		keyboard = new Scanner(System.in);
	}
	
	public String mainMenu() {
		System.out.println("");
		System.out.println("**************************************");
		System.out.println("*    WELCOME TO TOY STORE COMPANY!   *");
		System.out.println("**************************************");
		System.out.println("");
		System.out.println("How May We Help You?");
		System.out.println("");
		System.out.println("\t(1) Search Inventory and Purchse Toy");
		System.out.println("\t(2) Add New Toy");
		System.out.println("\t(3) Remove Toy");
		System.out.println("\t(4) Save & Exit\n");
		System.out.println("");
		System.out.println("Enter Option:");
		System.out.println("");
		String choice = keyboard.nextLine().toLowerCase();
		
		

		return choice;

	}
	public String submainMenu() {
		System.out.println("");
		System.out.println("Find Toys With:");
		System.out.println("");
		System.out.println("\t(1) Serial Name(SN)");
		System.out.println("\t(2) Toy Name");
		System.out.println("\t(3) Type");
		System.out.println("\t(4) Back tp Main Menu");
		System.out.println("");
		System.out.print("Enter Option:");
		System.out.println("");
		String choice = keyboard.nextLine().toLowerCase();
		
		

		return choice;
	}

	//***AddToy methods********************************************************************************************************************

	public String addSNPrompt() {
		String sn;
		System.out.println();
		System.out.println("Enter Serial Number (with 10 digits) :");
		sn = keyboard.nextLine().toLowerCase();
		//stop duplicates 
		//still needs the search method to find similar SN for if
		if(sn==null) {
			System.out.println("Wrong Input: Serial Number Exists");
		}else if(sn.length()>10 || sn.length()<10) {
			System.out.println("Worng Input: Need 10 Digits");
			
			
		}
		return sn;
	}
	
	public String addBasicData() {
		String genericData = null;
		String name;
		String brand;
		double price;
		int availCount;
		int ageMin;
		
		System.out.println("");
		System.out.println("Enter Toy Name:");
		name = keyboard.nextLine();
		System.out.println("");
		System.out.println("Enter Toy Brand:");
		brand = keyboard.nextLine();
		System.out.println("");
		System.out.println("Enter Toy Price eg. 5.00 :");
		price = keyboard.nextDouble();
		System.out.println("");
		System.out.println("Enter Available Count:");
		availCount = keyboard.nextInt();
		System.out.println("");
		System.out.println("Enter Appropriate Age:");
		ageMin = keyboard.nextInt();
		
		genericData = ";"+name+";"+ brand +";"+ price +";"+ availCount +";"+ ageMin+";";
		
		return genericData;
		
	}
	public String addFigureData() {
		String figureData = null;
		String type;
		System.out.println("");
		System.out.println("Enter Classification for figurine:");
		System.out.println("(A) Action Figure");
		System.out.println("(D) Doll Figure");
		System.out.println("(H) Historic Figure");
		
		type = keyboard.next().toUpperCase();
		System.out.println("");
		//test
		
		if(type.equals("A") || type.equals("D") || type.equals("H")) {
			figureData = type;
		}else {
			System.out.println("Wrong Input: input given options");
		}

		return figureData;
	}
	public String addAnimalData() {
		String animalData = null;
		String animalData1=null;
		String animalData2 = null ;
		String material;
		String size;
		System.out.println("");
		System.out.println("Enter Material: ");
		material = keyboard.next();
		animalData1 = material;
		System.out.println("");
		System.out.println("Enter Size:");
		System.out.println("(S) Small");
		System.out.println("(M) Medium");
		System.out.println("(L) Large");
		size = keyboard.next().toUpperCase();
		if(size.equals("S") || size.equals("M") || size.equals("L")) {
			animalData2 = size;;
		}else {
			System.out.println("Wrong Input: input given options");
		}
		animalData = animalData1 +";"+animalData2;

		
		return animalData;
	}
	public String addPuzzleData() {
		String puzzleData = null;
		String type;
		System.out.println("");
		System.out.println("Enter Classification for figurine:");
		System.out.println("(M) Mechanical Puzzle");
		System.out.println("(C) Cryptic Puzzle");
		System.out.println("(L) Logic Puzzle");
		System.out.println("(T) Trivia Puzzle");
		System.out.println("(R) Riddel Puzzle");

		type = keyboard.next().toUpperCase();
		
		if(type.equals("M") || type.equals("C") || type.equals("L")|| type.equals("T")|| type.equals("R")) {
			puzzleData = type;
		}else {
			System.out.println("Wrong Input: input given options");
		}
		
		return puzzleData;
	}
	public String addBoardGameData() {
		String boardGameData = null;
		String boardGameData1 = null;
		String boardGameData2 = null;
		
		int min  ;
		int max ;
		
		
		System.out.println("");
		System.out.println("Enter Minimum Amount of Players:");
		min = keyboard.nextInt();
		System.out.println();
		System.out.println("Enter Maximum Amount of Players");
		max = keyboard.nextInt();
		System.out.println("");
		System.out.println("Enter Designer Names (Use ',' to seperate names if greater than 1):");
		keyboard.nextLine();
		boardGameData2 = keyboard.nextLine();

		System.out.println("");
		
		boardGameData1 = min +"-"+max;
	boardGameData = boardGameData1 + ";" +boardGameData2;
		
		
		
		return boardGameData;
	}
	
}
