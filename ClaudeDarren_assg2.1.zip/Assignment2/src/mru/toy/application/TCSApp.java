package mru.toy.application;

import java.io.IOException;

import mru.toy.controller.ToyController;

public class TCSApp {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub

		new ToyController();
	}

}
