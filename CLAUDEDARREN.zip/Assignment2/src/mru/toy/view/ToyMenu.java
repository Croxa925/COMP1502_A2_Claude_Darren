package mru.toy.view;

import java.util.Scanner;

public class ToyMenu {
	
	Scanner keyboard;
	
	public ToyMenu() {
		keyboard = new Scanner(System.in);
	}
	
	public String mainMenu() {
		System.out.println("");
		System.out.println("**************************************");
		System.out.println("*    WELCOME TO TOY STORE COMPANY!   *");
		System.out.println("**************************************");
		System.out.println("");
		System.out.println("How May We Help You?");
		System.out.println("");
		System.out.println("\t(1) Search Inventory and Purchse Toy");
		System.out.println("\t(2) Add New Toy");
		System.out.println("\t(3) Remove Toy");
		System.out.println("\t(4) Save & Exit\n");
		System.out.println("");
		System.out.println("Enter Option:");
		System.out.println("");
		String choice = keyboard.nextLine().toLowerCase();
		
		

		return choice;

	}
	public String submainMenu() {
		System.out.println("");
		System.out.println("Find Toys With:");
		System.out.println("");
		System.out.println("\t(1) Serial Name(SN)");
		System.out.println("\t(2) Toy Name");
		System.out.println("\t(3) Type");
		System.out.println("\t(4) Back tp Main Menu");
		System.out.println("");
		System.out.print("Enter Option:");
		System.out.println("");
		String choice = keyboard.nextLine().toLowerCase();
		
		

		return choice;
	}
}
