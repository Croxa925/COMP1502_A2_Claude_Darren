package mru.toy.controller;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

import mru.toy.model.Toy;
import mru.toy.view.ToyMenu;

public class ToyController {
	private final String FILE_PATH = "toys.txt";
	ArrayList <Toy> toys;
	ToyMenu menu;
	
	public ToyController() throws IOException {
		toys = new ArrayList <Toy>();
		menu = new ToyMenu();
		//loadData();
		launchApp();
		
	}
	
	
	private void launchApp() throws IOException {
		boolean flag = true;
		String choice;

		while (flag) {
			choice = menu.mainMenu();

			switch (choice) {
			case "1":
				search(menu.submainMenu());
				break;
			case "2":
				addToy();
				
				break;
			case "3":
				removeToy();
				
				break;
			case "4":
				System.out.println("Thank you for your time!");
				flag = false;
				break;
			default:
				System.out.println("Invalid input, please try again");
				break; 
			}
		}
	}
	
private void search(String choice) throws IOException {
	switch(choice) {
	case "1":
		searchID();
		break;
	case"2":
		searchName();
		break;
	case"3":
		searchType();
		break;
	case "4":
		launchApp();
	
	}
}
//*****Search Menu methods******************************************************************************************************************
private void searchType() {
	// TODO Auto-generated method stub
	
}


private void searchName() {
	// TODO Auto-generated method stub
	
}


private void searchID() {
	// TODO Auto-generated method stub
	Scanner kb = new Scanner(System.in);
	int id = kb.nextInt();
	
	for(Toy t:toys) {
		if((t.getID()== id)== true) {
			System.out.println(t);
		}else {
			System.out.println("Toy Not Found");
		}
	}
}


//***Main Menu methods********************************************************************************************************************
private void removeToy() {
		// TODO Auto-generated method stub
		
	}


private void addToy() {
		// TODO Auto-generated method stub
		
	}
//***********************************************************************************************************************


public void loadData() throws FileNotFoundException {
		
		File db = new File (FILE_PATH);
		String currentInfo;
		String[] splittedLine;
		
		if(db.exists()) {
			Scanner fileReader = new Scanner (db);
			
			while (fileReader.hasNextLine()) {
				currentInfo = fileReader.nextLine();
				splittedLine = currentInfo.split(";");
				Toy s = new Toy(Integer.parseInt(splittedLine[0]),splittedLine[1],splittedLine[2], Double.parseDouble(splittedLine[3]),Integer.parseInt(splittedLine[4]));
				toys.add(s);
			}
			fileReader.close();
		}
	}
}
