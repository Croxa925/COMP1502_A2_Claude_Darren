package mru.toy.model;

public class BoardGame extends Toy {
	
	private int numofplayers;
	private String designers;
	public BoardGame(int iD, String name, String brand, double price, int available_count, int numofplayers,String designers) {
		
		super(iD, name, brand, price, available_count);
		this.numofplayers = numofplayers;
		this.designers = designers;
		
	}
	public int getNumofplayers() {
		return numofplayers;
	}
	public void setNumofplayers(int numofplayers) {
		this.numofplayers = numofplayers;
	}
	public String getDesigners() {
		return designers;
	}
	public void setDesigners(String designers) {
		this.designers = designers;
	}
	

}
