package mru.toy.model;

public class Toy {
	private int ID;
	private String name;
	private String Brand;
	private double price;
	private int available_count;
	
	public Toy(int iD, String name, String brand, double price, int available_count) {
		super();
		ID = iD;
		this.name = name;
		Brand = brand;
		this.price = price;
		this.available_count = available_count;
	 }

	public int getID() {
		return ID;
	}

	public void setID(int iD) {
		ID = iD;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getBrand() {
		return Brand;
	}

	public void setBrand(String brand) {
		Brand = brand;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public int getAvailable_count() {
		return available_count;
	}

	public void setAvailable_count(int available_count) {
		this.available_count = available_count;
	}
	}
	
