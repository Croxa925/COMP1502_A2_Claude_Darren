package mru.toy.model;

public class Figure {

}
