package mru.toy.model;

public class Puzzles extends Toy {
	
	private String puzzle_type;

	public Puzzles(int iD, String name, String brand, double price, int available_count, String puzzle_type) {
		super(iD, name, brand, price, available_count);
		this.puzzle_type = puzzle_type;
	}

	public String getPuzzle_type() {
		return puzzle_type;
	}

	public void setPuzzle_type(String puzzle_type) {
		this.puzzle_type = puzzle_type;
	}
	
}