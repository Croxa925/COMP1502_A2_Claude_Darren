package mru.toy.model;

public class Animals extends Toy{
	
	private String material;
	private int size;

	public Animals(int iD, String name, String brand, double price, int available_count, String material,int size) {
		super(iD, name, brand, price, available_count);
		this.material = material;
		this.size = size;
		
		// TODO Auto-generated constructor stub
	}
	
	public String getMaterial() {
		return material;
	}
	
	public void setMaterial(String material) {
		this.material = material;
	}
	
	public int getSize() {
		return size;
	}
	
	public void setSize(int size) {
		this.size = size;
	}

}
